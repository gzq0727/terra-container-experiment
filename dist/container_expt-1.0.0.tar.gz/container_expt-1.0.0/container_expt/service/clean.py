import terra.common.clean as _clean
from terra import exception
from terra.i18n import _

def clean_experiment(experiment):
    return experiment